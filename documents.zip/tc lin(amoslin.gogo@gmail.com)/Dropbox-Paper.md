# 🎉開始使用 Dropbox Paper
Dropbox Paper 非常適合捕捉團隊的想法並快速收集意見。您可以使用來自其他應用程式的文字、圖片、程式碼或媒體，或是連結行事曆，在上面加入專案待辦事項。

您可以*透過探索及編輯這份文件，來體驗其中幾項功能。請自由使用這份文件。除非您將文件分享出去，否則其他人都不會看到您的編輯內容。*


# 基本資訊

**選取文字**，格式工具列便會出現，讓您套用基本格式、建立清單，並加上留言。

[ ] 建立待辦事項清單
- 項目符號清單
1. 編號清單

**開始新的一行，**插入工具列便會出現，讓您添加來自其他應用程式的媒體、或加入 Dropbox 檔案和相片的連結等。

![](https://d2mxuefqeaa7sj.cloudfront.net/s_B904FAF77960EDE6FA9C8CC72C9D386C78DC133EA1C6DD287744532DF283811D_1532378472521_paper-insert_zh_TW.png)



**加入表情符號**到您的文件或留言之中，只要輸入「`**:**`」即可選擇表情符號。

# 👍 👎 👏 ✅ ❌ ❤️ ⭐ 💡 📌


# 圖片

**選取圖片，**圖片工具列便會出現，讓您將圖片靠左、置中、靠右對齊或貼齊頁面寬度。

![](https://d2mxuefqeaa7sj.cloudfront.net/s_72143DBFDAF4C9DE702BB246920BC47FE7E1FA76AC23CC699374430D94E96DD2_1523473869783_Hot_Sauce.jpg)


將圖片或 GIF 檔並列貼上，圖片會自動排列。在圖片上按兩下，就能開啟全螢幕圖庫檢視。


![](https://d2mxuefqeaa7sj.cloudfront.net/s_72143DBFDAF4C9DE702BB246920BC47FE7E1FA76AC23CC699374430D94E96DD2_1523564536543_Clock_Melt.png)
![](https://d2mxuefqeaa7sj.cloudfront.net/s_72143DBFDAF4C9DE702BB246920BC47FE7E1FA76AC23CC699374430D94E96DD2_1523564528339_Boom_Box_Melt.png)
![](https://d2mxuefqeaa7sj.cloudfront.net/s_72143DBFDAF4C9DE702BB246920BC47FE7E1FA76AC23CC699374430D94E96DD2_1523564549819_Soccerball_Melt.png)

![您也可以新增圖片說明](https://d2mxuefqeaa7sj.cloudfront.net/s_72143DBFDAF4C9DE702BB246920BC47FE7E1FA76AC23CC699374430D94E96DD2_1523564518899_Cacti_Melt.png)
![這台烤吐司機真怪，怎麼融化了？](https://d2mxuefqeaa7sj.cloudfront.net/s_72143DBFDAF4C9DE702BB246920BC47FE7E1FA76AC23CC699374430D94E96DD2_1523564508553_Toaster_Melt.png)


 


# 形式功能兼具，無須取捨

您和團隊可以用想要的素材，隨心所欲地打造文件。不管您的團隊如何捕捉靈感，Dropbox Paper 都能迎合您的需求。

**從應用程式新增媒體**，像是 YouTube 和 Vimeo 等等，或從 Spotify 和 SoundCloud 加入音檔。來自 Google Drive 和 Dropbox 的檔案會自動更新。建立新的一行，並從出現的選單中選擇操作選項，或是拖放網址至此試試看。

![](https://d2mxuefqeaa7sj.cloudfront.net/s_B904FAF77960EDE6FA9C8CC72C9D386C78DC133EA1C6DD287744532DF283811D_1532378483607_paper-embed_zh_TW.png)



## YouTube
https://www.youtube.com/watch?v=fmsq1uKOa08&


[https://youtu.be/fmsq1uKOa08](https://youtu.be/fmsq1uKOa08)



## SoundCloud
https://w.soundcloud.com/player/?url=https%3A%2F%2Fsoundcloud.com%2Ftycho%2Fspoon-inside-out-tycho-version&autoplay=false


[https://soundcloud.com/tycho/spoon-inside-out-tycho-version](https://soundcloud.com/tycho/spoon-inside-out-tycho-version) 



## Dropbox 檔案
https://www.dropbox.com/s/xb0qpt5sddetnp0/Wireframe%20render.pdf?dl=0




## 程式碼

**編寫程式碼**很方便，因為 Dropbox Paper 附有自動語言偵測及語法標記功能，只要在一行的開頭輸入三個反引號 (```) 即可開始編寫。


    public class HelloWorld { 
       public static void main(String[] args) { 
          System.out.println("Hello, World");
       }
    }



## 表格

**建立表格**的方式很簡單，只要在開始新的一行時，利用右邊出現的選單新增即可。

| 如要插入列或欄，請把滑鼠移動到分隔線上並點選 [+]     | ⭐     |
| ------------------------------ | ----- |
| 如要刪除，請選擇列/欄，然後按一下垃圾桶           | ⭐ ⭐   |
| 如要刪除整個表格，請在欄位中按一下，然後點選表格左上角的圓點 | ⭐ ⭐ ⭐ |





# 與大家通力合作

**邀請他人存取您的文件**，允許對方查看、留言及編輯。無論是團隊成員、廠商或利害關係人，都可以受邀存取您的文件。

![](https://d2mxuefqeaa7sj.cloudfront.net/s_B904FAF77960EDE6FA9C8CC72C9D386C78DC133EA1C6DD287744532DF283811D_1532378492924_paper-invite_zh_TW.png)


**供團隊成員查找您的文件**，只要將成員加入共享資料夾即可。您也可以使用僅限受邀者存取的資料夾，確保資料的私密性。


## 留言

**新增留言**：不論是針對單一字元、整份文件還是任何內容，只要反白就能輕鬆搞定。**加入貼圖**：按一下訊息方塊內的 😄 即可。


## 待辦事項

**提醒其他使用者注意留言或待辦事項**，只要輸入「**@**」並加上對方的姓名或電子郵件地址即可。輸入「**+**」和名稱，就能引用文件或資料夾。

[ ] 在待辦事項中提及他人，便會將事項指派給對方並以電子郵件通知 [@蔡翠華](http://蔡翠華)
[ ] 按一下日曆圖示，即可新增到期日 [@張凱佑](http://張凱佑) [@蔡翠華](http://蔡翠華)
[ ] 您也可以提及特定文件 [+ 🎉 開始使用 Dropbox Paper](http://#)



# 檔案帶著走

在 Android 或 iOS 手機和平板電腦上編輯、建立及分享 Paper 文件。可到 [App Store](https://itunes.apple.com/us/app/paper-by-dropbox/id1126623662) 和 [Google Play](https://play.google.com/store/apps/details?id=com.dropbox.paper) [商店](http://#)下載應用程式。



# 說明

**造訪**[**說明中心**](https://www.dropbox.com/help/topics/paper)進一步瞭解 Dropbox Paper。

**如需更多小提示**，按一下螢幕右下方的「**?**」並選擇「**提示和訣竅**」**。**

**如要提供意見，**請選擇螢幕右下方「**?**」底下的「意見回饋」。我們很期待聽見您的想法。

