# my thinking of 中國信通院發布 區塊鏈安全白皮書
在云计算当前主要提供的 3 种类型服务（IaaS、PaaS、SaaS）基 础之上，区块链与云计算结合发展出 BaaS（Blockchain as a Service， 区块链即服务）。BaaS 服务供应商旨在为用户提供更好的区块链服 务，因此 BaaS 服务商比区块链底层技术提供商更注重与垂直行业的 对接，提供合理的智能合约模板、良好的账户体系管理、良好的资源 管理工具和定制化的数据分析和报表系统。

http://www.caict.ac.cn/kxyj/qwfb/bps/201809/P020180905517892312190.pdf

