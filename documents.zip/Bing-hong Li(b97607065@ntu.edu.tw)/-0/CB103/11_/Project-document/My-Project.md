# My Project

# Business Understanding
## Determine Business Objectives
- Background
- Business Objectives
- Business Success Criteria
## Assess situation
- Inventory of Resources
- Requirements, Assumptions, and Constraints
- Risks and Contingencies
- Terminology
- Costs and Benefits
## Determine Data Mining Goals
- Data Mining Goals
- Data Mining Success Criteria
## Produce Project Plan
- Project Plan
- Initial Assessment of Tools and Technigues
# Data Understanding
## Collect Initial Data
- Initial Data Collection Report
## Describe Data
- Data Description Report
## Explore Data
- Data Exploration Report
## Verify Data Quality
- Data Quality Report
# Data Preparation
## Select Data
- Rationale for inclusion/Exclusion
## Clean Data
- Data Cleaning Report
## Construct Data
- Derived Attributes
- Generated Records
## Integrate Data
- Merged Data
## Format Data
- Reformatted Data

**Dataset**
Dataset Description

# Modeling
## Select Modeling Techniques
- Modeling Technique
- Modeling Assumptions
## Generate Test Design
- Test Design
## Build Model
- Parameter Settings
- Models
- Model Descriptions
## Assess Model
- Model Assessment
- Revised Parameter Settings
# Evaluation
## Evaluate Results
- Assessment of Data ( Mining Results w.r.t. Business Success Criteria)
- Approved Models
## Review Process
- Review of Process
## Determine Next Steps
- List of Possible Actions Decision
# Deployment
## Plan Deployment
- Deployment Plan
## Plan Monitoring and Maintenance
- Monitoring and Maintenance Plan
## Produce Final Report
- Final Report
- Final Presentation
## Review Project
- Experience

      Documentation


