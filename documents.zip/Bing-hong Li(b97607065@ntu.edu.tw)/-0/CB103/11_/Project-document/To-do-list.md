# To-do list

- Measure width/length of fish tank. - done
- Paste labels for marking water level. - done
- Measure pump watering speed. - done, 40 C.C. for 4 seconds.
- Line Chat Bot environment. - done.
- to try Classification for data analysis. - done. 

