# Milestone
2018-10-16 Tue. Start to insert data into MySQL.
2018-10-22 Mon. Set up the plant and watering system. 
2018-11-05 Mon. Set up a Wifi router for connecting Pi using wifi instead of wired/LAN cable.
2018-11-07 Wed. Output first .csv file.

https://www.dropbox.com/s/z04onzqdcer5lm5/sensor_pumpin.csv?dl=0


2018-11-21 Wed. Run mqtt+Kafka+elasticsearch+kibana data flow/solution.
2018-11-29 Fri. Run Line chat Bot. solution.
2018-12-14 Fri. Run modelling/equations

